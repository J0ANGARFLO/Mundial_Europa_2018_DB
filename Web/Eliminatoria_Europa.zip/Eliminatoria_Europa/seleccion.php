<!DOCTYPE html>
<html>
  <head>
    <title>Selección - Mundial 2018</title>
    <?php include('templates/head.html'); ?>
  </head>

  <body id="page-top">
    <header>
      <?php include('templates/header.html'); ?>
    </header>

    <section id="content-wrap">
      <div class="container">

        <div class="page-share hidden-print">
          <div class="header-share"></div>
        </div>

        <div class="navbar navbar-pageheader nav-scrollspy navbar-teamheader">
          <div class="container">
            <div class="fdh-wrap contentheader">
              <div class="fdh-thumb ">
                <img alt="España" title="España" src="img/iconos/escudo.png">
              </div>
              <div class="title-container">
                <h1>
                  <span class="fdh-flag ">
                    <img alt="España" title="España" src="img/paises/esp.png" class="flag">
                  </span>
                  España
                </h1>
              </div>
            </div>
          </div>
        </div>

        <div class="header-wrap nt-profile-wrap clearfix">
          <div class="title-wrap">
            <h2 class="title">
              <span>Perfil</span>
            </h2>
          </div>
        </div>

        <div class="cont_ini">
          <div class="row">
            <div class="col-md-1 col-lg-4">
              <div class="ph-lnd-4 figure i-wrap ">
                <a class="dcm-internal" target="_self" href="/worldcup/teams/team=43969/profile-detail.html">
                  <img alt="Foto Selección" title="Foto Selección" src="img/Foto_Seleccion.jpg" class="i-lnd-4">
                </a> 
              </div>
            </div>
            <div class="col-md-1 col-lg-4">
              <table class="table">
                <tbody>
                  <tr>
                    <td class="lista_iconos list_ico_DT"></td>
                    <td>Director Tecnico</td>
                  </tr>
                  <tr>
                    <td class="lista_iconos list_ico_Clasifico"></td>
                    <td>Clasifico</td>
                  </tr>
                  <tr>
                    <td class="lista_iconos list_ico_Estadio"></td>
                    <td>Estadio</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="col-md-1 col-lg-4">
              <table class="table">
                <tbody>
                  <tr>
                    <td class="num">14</td>
                    <td>Participaciones</td>
                  </tr>
                  <tr>
                    <td class="num">1</td>
                    <td>Títulos</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Estadísticas</span>
                </h2>
              </div>
            </div>

            <div class="col-xs-12 clear-grid">
              <table class="table tbl-standings " id="276499">
                <thead>
                  <tr>
                    <th class="tbl-light tbl-isqualified"></th>
                    <th class="tbl-teamname teamname-nolink">Equipo</th>
                    <th class="tbl-matchplayed"><span class="th-text">PJ</span></th>
                    <th class="tbl-win"><span class="th-text">G</span></th>
                    <th class="tbl-draw"><span class="th-text">E</span></th>
                    <th class="tbl-lost"><span class="th-text">P</span></th>
                    <th class="tbl-goalfor"><span class="th-text">GF</span></th>
                    <th class="tbl-goalagainst"><span class="th-text">GC</span></th>
                    <th class="tbl-diffgoal"><span class="th-text">+/-</span></th>
                    <th class="tbl-pts"><span class="th-text">Pts</span></th>
                  </tr>
                </thead>
                <tbody>
                  <tr data-url="/worldcup/edition=2018/_qualifiers/groups/content/round=276483/group=276499/_group_team_matches.html">
                    <td class="tbl-light tbl-isqualified"><span data-value="1">1</span></td>
                    <td class="tbl-teamname teamname-nolink">
                      <div class="t">
                        <div class="t-i i-4"><span class="t-i-wrap"><img alt="España" title="España" class="i-4-flag flag" src="//img.fifa.com/images/flags/4/esp.png" data-src="//img.fifa.com/images/flags/4/esp.png"></span></div>
                        <div class="t-n"><span class="t-nText">España</span></div>
                      </div>
                    </td>
                    <td class="tbl-matchplayed"><span class="text">10</span></td>
                    <td class="tbl-win"><span class="text">9</span></td>
                    <td class="tbl-draw"><span class="text">1</span></td>
                    <td class="tbl-lost"><span class="text">0</span></td>
                    <td class="tbl-goalfor"><span class="text">36</span></td>
                    <td class="tbl-goalagainst"><span class="text">3</span></td>
                    <td class="tbl-diffgoal"><span class="text">33</span></td>
                    <td class="tbl-pts"><span class="text">28</span></td>
                  </tr>
                </tbody>
              </table>          
            </div>

          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Jugadores</span>
                </h2>
              </div>
            </div>

            <div class="module">
              <div class="inner loaded" data-url="/worldcup/edition=2018/_qualifiers/teams/team=43969/_players/_players_list.html">
                <div class="p-list clearfix">
                  <div class="p p-i-no" data-player-id="175413" data-player-name="Pepe REINA">
                    <div class="p-n">
                      <a class="portfolio-item" href="#portfolio-modal-1">
                        <span class="p-n-webname">Pepe REINA</span>
                      </a>
                    </div>
                  </div>
                  <div class="p p-i-no" data-player-id="183857" data-player-name="Andres INIESTA">
                    <div class="p-n">
                      <a class="portfolio-item" href="#portfolio-modal-1">
                        <span class="p-n-webname">Andres INIESTA</span>
                      </a>
                    </div>
                  </div>
                  <div class="p p-i-no" data-player-id="200176" data-player-name="David SILVA">
                    <div class="p-n">
                      <a class="portfolio-item" href="#portfolio-modal-1">
                        <span class="p-n-webname">David SILVA</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>

    <!-- Modales Jugadores -->
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-1">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-10 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">David SILVA</h2>
              <hr class="star-dark mb-5">
              <div class="row">
                <div class="col-md-1 col-lg-6">
                  <table class="table">
                    <tbody>
                      <tr>
                        <td class="lista_iconos list_ico_Goles"></td>
                        <td class="num">1</td>
                        <td class="nom_dato_jugador">Goles</td>
                      </tr>
                      <tr>
                        <td class="lista_iconos list_ico_PJ"></td>
                        <td class="num">1</td>
                        <td class="nom_dato_jugador">Partidos jugados</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="col-md-1 col-lg-6">
                  <table class="table">
                    <tbody>
                      <tr>
                        <td class="lista_iconos list_ico_Tarjetas"></td>
                        <td class="num">14</td>
                        <td class="nom_dato_jugador">Amarillas</td>
                      </tr>
                      <tr>
                        <td class="lista_iconos list_ico_Tarjetas"></td>
                        <td class="num">1</td>
                        <td class="nom_dato_jugador">Rojas</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer>
    	<?php include('templates/footer.html'); ?>
    </footer>

    <!-- Botón para desplazarse a la parte superior de la pantalla (solo visible en tamaños de pantalla pequeñas y extra pequeñas) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Scripts personalizados para esta plantilla -->
    <script src="js/script.js"></script>
  </body>
</html>