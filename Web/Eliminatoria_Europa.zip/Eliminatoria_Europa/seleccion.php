<!DOCTYPE html>
<html>
  <head>
    <title>Selección - Mundial 2018</title>
    <?php 
      error_reporting(E_ALL);
      ini_set('display_errors', '1');

      include('templates/head.html'); 
      include 'database/conexionDB.php';
    ?>
  </head>

  <body id="page-top">
    <header>
      <?php include('templates/header.html'); ?>
    </header>

    <section id="content-wrap">
      <div class="container">

        <div class="page-share hidden-print">
          <div class="header-share"></div>
        </div>

        <div class="navbar navbar-pageheader nav-scrollspy navbar-teamheader">
          <div class="container">
            <div class="fdh-wrap contentheader">
              <div class="fdh-thumb ">
                <img alt="España" title="España" src="img/iconos/escudo.png">
              </div>
              <div class="title-container">
                <h1>
                  <?php include 'database/selecciones.php'; ?>
                </h1>
              </div>
            </div>
          </div>
        </div>

        <div class="header-wrap nt-profile-wrap clearfix">
          <div class="title-wrap">
            <h2 class="title">
              <span>Perfil</span>
            </h2>
          </div>
        </div>

        <div class="cont_ini">
          <div class="row">
            <div class="col-md-1 col-lg-4">
              <div class="ph-lnd-4 figure i-wrap ">
                <a class="dcm-internal" target="_self" href="/worldcup/teams/team=43969/profile-detail.html">
                  <img alt="Foto Selección" title="Foto Selección" src="img/Foto_Seleccion.jpg" class="i-lnd-4">
                </a> 
              </div>
            </div>

            <?php include ('database/perfil_seleccion.php'); ?>

          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Estadísticas</span>
                </h2>
              </div>
            </div>

            <div class="col-xs-12 clear-grid">
              <table class="table tbl-standings " id="276499">
                <thead>
                  <tr>
                    <th class="tbl-light tbl-isqualified"></th>
                    <th class="tbl-teamname teamname-nolink">Equipo</th>
                    <th class="tbl-matchplayed"><span class="th-text">PJ</span></th>
                    <th class="tbl-win"><span class="th-text">G</span></th>
                    <th class="tbl-draw"><span class="th-text">E</span></th>
                    <th class="tbl-lost"><span class="th-text">P</span></th>
                    <th class="tbl-goalfor"><span class="th-text">GF</span></th>
                    <!-- <th class="tbl-goalagainst"><span class="th-text">GC</span></th>
                    <th class="tbl-diffgoal"><span class="th-text">+/-</span></th> -->
                    <th class="tbl-pts"><span class="th-text">Pts</span></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="tbl-light tbl-isqualified"><span data-value="1">1</span></td>
                    <?php include ('database/estadisticas_seleccion.php'); ?>
                  </tr>
                </tbody>
              </table>          
            </div>

          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Jugadores</span>
                </h2>
              </div>
            </div>

            <div class="module">
              <div class="inner loaded">
                <div class="p-list clearfix">
                  <?php include ('database/jugadores_seleccion.php'); ?>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>

    <!-- Modales Jugadores -->
    <?php include ('database/PopUp_jugadores_seleccion.php'); ?>

    <footer>
    	<?php include('templates/footer.html'); ?>
    </footer>

    <!-- Botón para desplazarse a la parte superior de la pantalla (solo visible en tamaños de pantalla pequeñas y extra pequeñas) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Scripts personalizados para esta plantilla -->
    <script src="js/script.js"></script>
  </body>
</html>