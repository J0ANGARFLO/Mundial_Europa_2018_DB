<!DOCTYPE html>
<html>
  <head>
    <title>Eliminatorias Europa - Mundial 2018</title>
    <?php 
      error_reporting(E_ALL);
      ini_set('display_errors', '1');

      include ('templates/head.html');
      include 'database/conexionDB.php';
    ?>
  </head>

  <body id="page-top">
    <header>
      <?php include('templates/header.html'); ?>
    </header>

    <section id="content-wrap">
      <div class="container">

        <div class="page-share hidden-print">
          <div class="header-share"></div>
        </div>
        <div class="header-wrap ">
          <div class="title-wrap">
            <h1 class="title">
              <span>Eliminatorias</span>
            </h1>
          </div>
        </div>

        <div id="cont_confederaciones">
          <div class="row">
            <?php include 'database/confederaciones.php'; ?>
          </div>
        </div>

        <div id="cont_equipos_clasi">
          <div class="row">
            <div class="col-md-4 col-lg-2 clear-grid ">
              <div class="team-qualifiedteams">
                <h4 class="title">Equipos clasificados</h4>
                <ul>
                  <li>
                    <a href="#" class="team">
                      <img alt="Egipto" title="Egipto" class="flag" src="img/paises/egy.png">
                      <span class="team-name">Egipto</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Marruecos" title="Marruecos" class="flag" src="img/paises/mar.png">
                      <span class="team-name">Marruecos</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Nigeria" title="Nigeria" class="flag" src="img/paises/nga.png">
                      <span class="team-name">Nigeria</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Senegal" title="Senegal" class="flag" src="img/paises/sen.png">
                      <span class="team-name">Senegal</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Túnez" title="Túnez" class="flag" src="img/paises/tun.png">
                      <span class="team-name">Túnez</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-md-4 col-lg-2">
              <div class="team-qualifiedteams">
                <h4 class="title">Equipos clasificados</h4>
                <ul>
                  <li>
                    <a href="#" class="team">
                      <img alt="Arabia Saudí" title="Arabia Saudí" class="flag" src="img/paises/ksa.png">
                      <span class="team-name">Arabia Saudí</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Australia" title="Australia" class="flag" src="img/paises/aus.png">
                      <span class="team-name">Australia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Irán" title="Irán" class="flag" src="img/paises/irn.png">
                      <span class="team-name">Irán</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Japón" title="Japón" class="flag" src="img/paises/jpn.png">
                      <span class="team-name">Japón</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="República de Corea" title="República de Corea" class="flag" src="img/paises/kor.png">
                      <span class="team-name">República de Corea</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-md-4 col-lg-2">
              <div class="team-qualifiedteams">
                <h4 class="title">Equipos clasificados</h4>
                <ul>
                  <li>
                    <a href="#" class="team">
                      <img alt="Alemania" title="Alemania" class="flag" src="img/paises/ger.png">
                      <span class="team-name">Alemania</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Bélgica" title="Bélgica" class="flag" src="img/paises/bel.png">
                      <span class="team-name">Bélgica</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Croacia" title="Croacia" class="flag" src="img/paises/cro.png">
                      <span class="team-name">Croacia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Dinamarca" title="Dinamarca" class="flag" src="img/paises/den.png">
                      <span class="team-name">Dinamarca</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="España" title="España" class="flag" src="img/paises/esp.png">
                      <span class="team-name">España</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Francia" title="Francia" class="flag" src="img/paises/fra.png">
                      <span class="team-name">Francia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Inglaterra" title="Inglaterra" class="flag" src="img/paises/eng.png">
                      <span class="team-name">Inglaterra</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Islandia" title="Islandia" class="flag" src="img/paises/isl.png">
                      <span class="team-name">Islandia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Polonia" title="Polonia" class="flag" src="img/paises/pol.png">
                      <span class="team-name">Polonia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Portugal" title="Portugal" class="flag" src="img/paises/por.png">
                      <span class="team-name">Portugal</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Rusia" title="Rusia" class="flag" src="img/paises/rus.png">
                      <span class="team-name">Rusia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#ml" class="team">
                      <img alt="Serbia" title="Serbia" class="flag" src="img/paises/srb.png">
                      <span class="team-name">Serbia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Suecia" title="Suecia" class="flag" src="img/paises/swe.png">
                      <span class="team-name">Suecia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Suiza" title="Suiza" class="flag" src="img/paises/sui.png">
                      <span class="team-name">Suiza</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-md-4 col-lg-2">
              <div class="team-qualifiedteams">
                <h4 class="title">Equipos clasificados</h4>
                <ul>
                  <li>
                    <a href="#" class="team">
                      <img alt="Costa Rica" title="Costa Rica" class="flag" src="img/paises/crc.png">
                      <span class="team-name">Costa Rica</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="México" title="México" class="flag" src="img/paises/mex.png">
                      <span class="team-name">México</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Panamá" title="Panamá" class="flag" src="img/paises/pan.png">
                      <span class="team-name">Panamá</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-md-4 col-lg-2">
              <div class="team-qualifiedteams"> </div>
            </div>
            <div class="col-md-4 col-lg-2">
              <div class="team-qualifiedteams">
                <h4 class="title">Equipos clasificados</h4>
                <ul>
                  <li>
                    <a href="#" class="team">
                      <img alt="Argentina" title="Argentina" class="flag" src="img/paises/arg.png">
                      <span class="team-name">Argentina</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Brasil" title="Brasil" class="flag" src="img/paises/bra.png">
                      <span class="team-name">Brasil</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Colombia" title="Colombia" class="flag" src="img/paises/col.png">
                      <span class="team-name">Colombia</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Perú" title="Perú" class="flag" src="img/paises/per.png">
                      <span class="team-name">Perú</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" class="team">
                      <img alt="Uruguay" title="Uruguay" class="flag" src="img/paises/uru.png">
                      <span class="team-name">Uruguay</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer>
    	<?php include('templates/footer.html'); ?>
    </footer>

    <!-- Botón para desplazarse a la parte superior de la pantalla (solo visible en tamaños de pantalla pequeñas y extra pequeñas) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Scripts personalizados para esta plantilla -->
    <script src="js/script.js"></script>
  </body>
</html>