<?php 
  
  $FedActiv = $_GET['Fed'];

  $queryDT = "SELECT nom_persona, ape_persona FROM directorestecnicos DT INNER JOIN personas P ON DT.cod_persona = P.cod_persona WHERE DT.cod_pais = '$FedActiv'";
  $resultadoDT = pg_query($conexion, $queryDT) or die("Error en la Consulta SQL");
  $numRegDT = pg_num_rows($resultadoDT);

  $queryCiudad = "SELECT nomb_ciudad FROM ciudades WHERE cod_pais = '$FedActiv'";
  $resultadoCiudad = pg_query($conexion, $queryCiudad) or die("Error en la Consulta SQL");
  $numRegCiudad = pg_num_rows($resultadoCiudad);

  $query = "SELECT clasifico FROM vinfo_equipos WHERE cod_pais = '$FedActiv'";
  $resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");

  if ($numRegDT > 0) {

    $filaDT = pg_fetch_array($resultadoDT);
    $fila = pg_fetch_array($resultado);
    
    echo "<div class='col-md-1 col-lg-4'>
      <table class='table'>
        <tbody>
          <tr>
            <td class='lista_iconos list_ico_DT'></td>
            <td>".$filaDT['nom_persona']." ".$filaDT['ape_persona']."</td>
          </tr>
          <tr>
            <td class='lista_iconos list_ico_Clasifico'></td>
            <td>Clasifico: ".$fila['clasifico']."</td>
          </tr>
          <tr>
            <td class='lista_iconos list_ico_Estadio'></td>";
  } else {
    echo "<div class='col-md-1 col-lg-4'>
      <table class='table'>
        <tbody>
          <tr>
            <td class='lista_iconos list_ico_DT'></td>
            <td>N.N</td>
          </tr>
          <tr>
            <td class='lista_iconos list_ico_Clasifico'></td>
            <td>Clasifico: N.N</td>
          </tr>
          <tr>
            <td class='lista_iconos list_ico_Estadio'></td>";
  }

  if ($numRegCiudad > 0) {

    $filaCiudad = pg_fetch_array($resultadoCiudad);

            echo "<td>".$filaCiudad['nomb_ciudad']."</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class='col-md-1 col-lg-4'>
      <table class='table'>
        <tbody>
          <tr>
            <td class='num'></td>
            <td>Participaciones</td>
          </tr>
          <tr>
            <td class='num'></td>
            <td>Títulos</td>
          </tr>
        </tbody>
      </table>
    </div>";
  } else {
            echo "<td>N.N</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class='col-md-1 col-lg-4'>
      <table class='table'>
        <tbody>
          <tr>
            <td class='num'></td>
            <td>Participaciones</td>
          </tr>
          <tr>
            <td class='num'></td>
            <td>Títulos</td>
          </tr>
        </tbody>
      </table>
    </div>";
  }
?>


