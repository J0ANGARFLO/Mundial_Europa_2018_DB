<?php
	$query = "SELECT nombre_confe FROM confederaciones ORDER BY nombre_confe";

	$resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");

	$numReg = pg_num_rows($resultado);

	if($numReg>0){
		while ($fila=pg_fetch_array($resultado)) {
      echo "<div class='col-md-4 col-lg-2'>
        <a href='confederacion.php?Confed=".$fila['nombre_confe']."'>
          <div class='cont_img_mapa'>
            <img src='img/confederaciones/".$fila['nombre_confe'].".jpg' width='148px' height='148px'>
          </div>
          <div class='cont_nom_mapa'>
            <span>".$fila['nombre_confe']."</span>
          </div>
        </a>
      </div>";
		}
	}else{
		echo "No hay Registros";
	}

	pg_close($conexion);
?>