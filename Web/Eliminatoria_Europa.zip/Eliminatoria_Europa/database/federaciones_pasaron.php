<?php
  
  $ConfedActiv = $_GET['Confed'];

	$query = "SELECT DISTINCT nomb_equipo, cod_pais FROM vinfo_equipos WHERE nombre_confe = '$ConfedActiv' AND clasifico = 'SI' ORDER BY nomb_equipo";

	$resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");

	$numReg = pg_num_rows($resultado);

  echo "
    <script type='text/javascript'>
      document.getElementById('num_equipos_pasaron').innerHTML=$numReg;
    </script>
  ";

	if($numReg>0){
		while ($fila=pg_fetch_array($resultado)) {
			
			echo "
      <li class='item-team'>
        <a href='seleccion.php?Fed=".$fila['cod_pais']."'>
          <div class='t'>
            <div class='t-i i-2'>
              <span class='t-i-wrap'>
                <img title='".$fila['nomb_equipo']."' class='".$fila['cod_pais']." i-2-flag flag' alt='".$fila['nomb_equipo']."' src='img/paises/".$fila['cod_pais'].".png'>
              </span>
            </div>
            <div class='t-n'>
              <span class='t-nTri'>".$fila['cod_pais']."</span>
              <span class='t-nText '>".$fila['nomb_equipo']."</span>
            </div>
          </div>
        </a>
      </li>";
		}
	}else{
		echo "No hay Registros";
	}

	pg_close($conexion);
?>