<?php
  $ConfedActiv = $_GET['Confed'];

  echo "<div class='col-md-6 col-lg-10'>
    <div class='header-wrap '>
      <div class='title-wrap'>
        <h1 class='title'>
          <span>$ConfedActiv</span>
        </h1>
      </div>
    </div>
    <div>";
      // <p>Aquí debería ir un texto alusivo a la confederación.</p>.
    echo "</div>
  </div>
  <div class='col-md-4 col-lg-2'>
    <div class='cont_img_mapa'>
      <img src='img/confederaciones/$ConfedActiv.jpg' width='148px' height='148px'>
    </div>
  </div>";
?>