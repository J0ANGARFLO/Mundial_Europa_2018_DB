<?php 

    $FedActiv = $_GET['Fed'];

    $query = "SELECT * FROM vinfo_equipos WHERE cod_pais = '$FedActiv'";

    $resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");

    $numReg = pg_num_rows($resultado);

    if($numReg>0){
        $fila = pg_fetch_array($resultado);

        $PG = $fila['cganadores'];
        $PP = $fila['cperdedores'];
        $PE = $fila['cempatados'];
        $PJ = $PG+$PP+$PE;


        echo "<td class='tbl-teamname teamname-nolink'>
                <div class='t'>
                    <div class='t-i i-4'>
                        <span class='t-i-wrap'>
                            <img alt='".$fila['nomb_equipo']."' title='".$fila['nomb_equipo']."' class='i-4-flag flag' src='img/paises/$FedActiv.png'>
                        </span>
                    </div>
                    <div class='t-n'><span class='t-nText'>".$fila['nomb_equipo']."</span></div>
                </div>
            </td>
            <td class='tbl-matchplayed'><span class='text'>$PJ</span></td>
            <td class='tbl-win'><span class='text'>".$fila['cganadores']."</span></td>
            <td class='tbl-draw'><span class='text'>".$fila['cempatados']."</span></td>
            <td class='tbl-lost'><span class='text'>".$fila['cperdedores']."</span></td>
            <td class='tbl-goalfor'><span class='text'>".$fila['goles']."</span></td>";
            // <td class='tbl-goalagainst'><span class='text'>3</span></td>
            // <td class='tbl-diffgoal'><span class='text'>33</span></td>
        echo "<td class='tbl-pts'><span class='text'>".$fila['puesto']."</span></td>";
    }else{
        echo "<td class='tbl-teamname teamname-nolink'>
                <div class='t'>
                    <div class='t-i i-4'>
                        <span class='t-i-wrap'>
                            <img alt='N.N' title='N.N' class='i-4-flag flag' src='img/paises/$FedActiv.png'>
                        </span>
                    </div>
                    <div class='t-n'><span class='t-nText'>N.N</span></div>
                </div>
            </td>
            <td class='tbl-matchplayed'><span class='text'>10</span></td>
            <td class='tbl-win'><span class='text'>9</span></td>
            <td class='tbl-draw'><span class='text'>1</span></td>
            <td class='tbl-lost'><span class='text'>0</span></td>
            <td class='tbl-goalfor'><span class='text'>36</span></td>";
            // <td class='tbl-goalagainst'><span class='text'>3</span></td>
            // <td class='tbl-diffgoal'><span class='text'>33</span></td>
        echo "<td class='tbl-pts'><span class='text'>28</span></td>";
    }

?>


