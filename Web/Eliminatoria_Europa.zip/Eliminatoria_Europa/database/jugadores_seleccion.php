<?php 

	$FedActiv = $_GET['Fed'];

	$queryJugador = "SELECT nom_persona, ape_persona, cod_jugador FROM jugadores_uefa WHERE cod_pais = '$FedActiv'";
	$resultadoJugador = pg_query($conexion, $queryJugador) or die("Error en la Consulta SQL");
  $numRegJugador = pg_num_rows($resultadoJugador);

  if ($numRegJugador > 0) {

  	while ($filaJugador = pg_fetch_array($resultadoJugador)) {
  		echo "
	    	<div class='p p-i-no' data-player-id='".$filaJugador['cod_jugador']."' data-player-name='".$filaJugador['nom_persona']." ".$filaJugador['ape_persona']."'>
          <div class='p-n'>
            <a class='portfolio-item' href='#portfolio-modal-".$filaJugador['cod_jugador']."'>
              <span class='p-n-webname'>".$filaJugador['nom_persona']." ".$filaJugador['ape_persona']."</span>
            </a>
          </div>
        </div>
	    ";
    }
  } else {
    echo "No hay Registros";
  }

?>