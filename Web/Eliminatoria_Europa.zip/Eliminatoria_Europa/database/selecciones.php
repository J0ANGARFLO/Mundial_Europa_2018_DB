<?php

	$FedActiv = $_GET['Fed'];

	$query = "SELECT * FROM pais WHERE cod_pais = '$FedActiv'";

	$resultado = pg_query($conexion, $query) or die("Error en la Consulta SQL");

	$numReg = pg_num_rows($resultado);

	if($numReg>0){
		$fila = pg_fetch_array($resultado);

		echo "<span class='fdh-flag '>
      <img alt='".$fila['nomb_pais']."' title='".$fila['nomb_pais']."' src='img/paises/$FedActiv.png' class='flag'>
    </span> ".$fila['nomb_pais']." ";
	}else{
		echo "<span class='fdh-flag '>
      <img alt='N.N' title='N.N' src='img/paises/$FedActiv.png' class='flag'>
    </span> N.N ";
	}

	// pg_close($conexion);
?>