<?php 

	$FedActiv = $_GET['Fed'];

	$queryJugador = "SELECT nom_persona, ape_persona, cod_jugador, goles, rojas, amarillas, part_jugados FROM jugadores_uefa WHERE cod_pais = '$FedActiv'";
	$resultadoJugador = pg_query($conexion, $queryJugador) or die("Error en la Consulta SQL");
  $numRegJugador = pg_num_rows($resultadoJugador);

  if ($numRegJugador > 0) {

  	while ($filaJugador = pg_fetch_array($resultadoJugador)) {

      echo "

      <div class='portfolio-modal mfp-hide' id='portfolio-modal-".$filaJugador['cod_jugador']."'>
        <div class='portfolio-modal-dialog bg-white'>
          <a class='close-button d-none d-md-block portfolio-modal-dismiss' href='#'>
            <i class='fa fa-3x fa-times'></i>
          </a>
          <div class='container text-center'>
            <div class='row'>
              <div class='col-lg-10 mx-auto'>
                <h2 class='text-secondary text-uppercase mb-0'>".$filaJugador['nom_persona']." ".$filaJugador['ape_persona']."</h2>
                <hr class='star-dark mb-5'>
                <div class='row'>
                  <div class='col-md-1 col-lg-6'>
                    <table class='table'>
                      <tbody>
                        <tr>
                          <td class='lista_iconos list_ico_Goles'></td>
                          <td class='num'>".$filaJugador['goles']."</td>
                          <td class='nom_dato_jugador'>Goles</td>
                        </tr>
                        <tr>
                          <td class='lista_iconos list_ico_PJ'></td>
                          <td class='num'>".$filaJugador['part_jugados']."</td>
                          <td class='nom_dato_jugador'>Partidos jugados</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class='col-md-1 col-lg-6'>
                    <table class='table'>
                      <tbody>
                        <tr>
                          <td class='lista_iconos list_ico_Tarjetas'></td>
                          <td class='num'>".$filaJugador['rojas']."</td>
                          <td class='nom_dato_jugador'>Tarjetas roja</td>
                        </tr>
                        <tr>
                          <td class='lista_iconos list_ico_Tarjetas'></td>
                          <td class='num'>".$filaJugador['amarillas']."</td>
                          <td class='nom_dato_jugador'>Tarjetas amarillas</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      ";
    }
  } else {
    echo "No hay Registros";
  }

?>