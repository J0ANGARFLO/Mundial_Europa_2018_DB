<!DOCTYPE html>
<html>
  <head>
    <title>Confederación - Mundial 2018</title>
    <?php 
      error_reporting(E_ALL);
      ini_set('display_errors', '1');

      include ('templates/head.html'); 
      include ('database/conexionDB.php');
    ?>
  </head>

  <body id="page-top">
    <header>
      <?php include ('templates/header.html'); ?>
    </header>

    <section id="content-wrap">
      <div class="container">

        <div class="page-share hidden-print">
          <div class="header-share"></div>
        </div>

        <div class="cont_ini">
          <div class="row">
            <?php include ('database/head_confed.php'); ?>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Selecciones</span>
                </h2>
              </div>
            </div>

            <div class="rule-participation">
              <div class="num-team">
                <span id="num_equipos"></span>
              </div>
              <div class="rule-text">
                <span>selecciones disputan la primera ronda</span>
              </div>
            </div>

            <div class="list-team">
              <ul>
                <?php include 'database/federaciones.php'; ?>
              </ul>
            </div>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="final-round-rule" id="254645">
              <div class="header">
                <div class="comp-logo"><img src="img/Header/2018.png"></div>
                <div class="comp-name-info">
                  <div class="comp-name">Copa Mundial de la FIFA Rusia 2018</div>
                </div>
              </div>

              <div class="rule-participation">
                <div class="num-team">
                  <span id="num_equipos_pasaron"></span>
                </div>
                <div class="rule-text">
                  <span>selecciones van al mundial</span>
                </div>
              </div>


              <div class="team-list-wrap">
                <ul class="team-before">
                  <?php include 'database/federaciones_pasaron.php'; ?>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Goleador confederación</span>
                </h2>
              </div>
            </div>

            <div class="people-profile">
              <div class="col-xs-12 clear-grid ">
                <div class="players">
                    <div class="info-people-profile no-img">
                      <div class="line general-info">
                        <div class="t" data-team-id="140">
                          <div class="t-i i-2">
                            <span class="t-i-wrap">
                              <img src="img/paises/pol.png" alt="Polonia" title="Polonia" class="POL i-2-flag flag">
                            </span>
                          </div>
                          <div class="t-n">
                            <span class="t-nText ">Polonia</span>
                            <span class="t-nTri">POL</span>
                          </div>
                        </div>
                        <div class="people-dob">
                          <a href="#">
                            <span class="description">Robert LEWANDOWSKI</span><br>
                          </a>
                          <span class="data">Goles Marcados: 16</span>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <footer>
    	<?php include('templates/footer.html'); ?>
    </footer>

    <!-- Botón para desplazarse a la parte superior de la pantalla (solo visible en tamaños de pantalla pequeñas y extra pequeñas) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Scripts personalizados para esta plantilla -->
    <script src="js/script.js"></script>
  </body>
</html>