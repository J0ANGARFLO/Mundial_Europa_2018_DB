<!DOCTYPE html>
<html>
  <head>
    <title>Confederación - Mundial 2018</title>
    <?php include('templates/head.html'); ?>
  </head>

  <body id="page-top">
    <header>
      <?php include('templates/header.html'); ?>
    </header>

    <section id="content-wrap">
      <div class="container">

        <div class="page-share hidden-print">
          <div class="header-share"></div>
        </div>

        <div class="cont_ini">
          <div class="row">
            <div class="col-md-6 col-lg-10">
              <div class="header-wrap ">
                <div class="title-wrap">
                  <h1 class="title">
                    <span>Europa</span>
                  </h1>
                </div>
              </div>
              <div>
                <p>La competencia preliminar europea es la que cuenta con mayor cantidad de cupos disponibles para disputar la fase final de la Copa Mundial de la FIFA Rusia 2018: 13 en total.</p>
              </div>
            </div>
            <div class="col-md-4 col-lg-2">
              <div class="cont_img_mapa">
                <img src="img/confederaciones/europe.jpg" width="148px" height="148px">
              </div>
            </div>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Selecciones</span>
                </h2>
              </div>
            </div>

            <div class="rule-participation">
              <div class="num-team">
                <span>54</span>
              </div>
              <div class="rule-text">
                <span>selecciones disputan la primera ronda</span>
              </div>
            </div>

            <div class="list-team">
              <ul>
                <li class="item-team">
                  <a href="/worldcup/teams/team=43932/index.html">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Albania" class="ALB i-2-flag flag" alt="Albania" src="img/paises/alb.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">ALB</span>
                        <span class="t-nText ">Albania</span>
                      </div>
                    </div>
                  </a>
                </li>
                <li class="item-team">
                  <a href="/worldcup/teams/team=20001/index.html">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Andorra" class="AND i-2-flag flag" alt="Andorra" src="img/paises/and.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">AND</span>
                        <span class="t-nText ">Andorra</span>
                      </div>
                    </div>
                  </a>
                </li>
                <li class="item-team">
                  <a href="/worldcup/teams/team=43933/index.html">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Armenia" class="ARM i-2-flag flag" alt="Armenia" src="img/paises/arm.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">ARM</span>
                        <span class="t-nText ">Armenia</span>
                      </div>
                    </div>
                  </a>
                </li>
                <li class="item-team">
                  <a href="/worldcup/teams/team=43934/index.html">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Austria" class="AUT i-2-flag flag" alt="Austria" src="img/paises/aut.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">AUT</span>
                        <span class="t-nText ">Austria</span>
                      </div>
                    </div>
                  </a>
                </li>
                <li class="item-team">
                  <a href="/worldcup/teams/team=43994/index.html">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Azerbaiyán" class="AZE i-2-flag flag" alt="Azerbaiyán" src="img/paises/aze.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">AZE</span>
                        <span class="t-nText ">Azerbaiyán</span>
                      </div>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="final-round-rule" id="254645">
              <div class="header">
                <div class="comp-logo"><img src="img/Header/2018.png"></div>
                <div class="comp-name-info">
                  <div class="comp-name">Copa Mundial de la FIFA Rusia 2018</div>
                </div>
              </div>

              <div class="team-list-wrap">
                <ul class="team-before">
                  <li class="item-team">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Alemania" class="GER i-2-flag flag" alt="Alemania" src="img/paises/ger.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">GER</span>
                        <span class="t-nText ">Alemania</span>
                      </div>
                    </div>
                  </li>
                  <li class="item-team">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Bélgica" class="BEL i-2-flag flag" alt="Bélgica" src="img/paises/bel.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">BEL</span>
                        <span class="t-nText ">Bélgica</span>
                      </div>
                    </div>
                  </li>
                  <li class="item-team">
                    <div class="t">
                      <div class="t-i i-2">
                        <span class="t-i-wrap">
                          <img title="Croacia" class="CRO i-2-flag flag" alt="Croacia" src="img/paises/cro.png">
                        </span>
                      </div>
                      <div class="t-n">
                        <span class="t-nTri">CRO</span>
                        <span class="t-nText ">Croacia</span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="cont_ini">
          <div class="col-lg-12">
            <div class="header-wrap">
              <div class="title-wrap">
                <h2 class="title">
                  <span class="round-name">Goleador confederación</span>
                </h2>
              </div>
            </div>

            <div class="people-profile">
              <div class="col-xs-12 clear-grid ">
                <div class="players">
                    <div class="info-people-profile no-img">
                      <div class="line general-info">
                        <div class="t" data-team-id="140">
                          <div class="t-i i-2">
                            <span class="t-i-wrap">
                              <img src="img/paises/pol.png" alt="Polonia" title="Polonia" class="POL i-2-flag flag">
                            </span>
                          </div>
                          <div class="t-n">
                            <span class="t-nText ">Polonia</span>
                            <span class="t-nTri">POL</span>
                          </div>
                        </div>
                        <div class="people-dob">
                          <a href="#">
                            <span class="description">Robert LEWANDOWSKI</span><br>
                          </a>
                          <span class="data">Goles Marcados: 16</span>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <footer>
    	<?php include('templates/footer.html'); ?>
    </footer>

    <!-- Botón para desplazarse a la parte superior de la pantalla (solo visible en tamaños de pantalla pequeñas y extra pequeñas) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Scripts personalizados para esta plantilla -->
    <script src="js/script.js"></script>
  </body>
</html>